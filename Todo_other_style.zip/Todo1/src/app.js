const express = require("express");
const mongoose = require("mongoose");
const path = require("path")
const hbs = require("hbs")

const app = express();

//conenction to mongodb
mongoose.connect("mongodb://0.0.0.0:27017/userlogin", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(()=>{
  console.log("connectd")
}).catch((e)=>{
  console.log(e);
})


// middlewares
app.use(express.urlencoded({ extended: true }));
const Static =path.join(__dirname, "../public");
app.use(express.static(Static));
const pars =path.join(__dirname, "../tem/pars");

app.use(express.static(path.join(__dirname,"../tem/views")));
app.set("view engine","hbs");

hbs.registerPartials(pars);



app.get("",(req,res)=>{
    res.render("../tem/views/index")
});


// mongoose.connect("mongodb://0.0.0.0:27017/userlogin", {
//       useNewUrlParser: true,
//     useUnifiedTopology: true,
// }).then(()=>{
//   console.log("connectd")
  
// }).catch((e)=>{
//   console.log(e);
// })

// app.use(express.urlencoded({ extended: true }));
// app.use(express.static("../public"));
// app.set("view engine", "ejs");



// // routes
 app.use(require("../routes/index"))
 app.use(require("../routes/todo"))

var server = app.listen(8081, function () {
  var host = server.address().address
  var port = server.address().port
  
  console.log("Example app listening at http://%s:%s", host, port)
})
