const router = require("express").Router()
const Todo = require("../models/Todo.js")
const mongoose = require("mongoose");



// routes will be here....
router.get("/", async(req, res) => {
    //const allTodo = await Todo.find();
    // res.render("index")
    // let data = new Todo({todo:"hello parth"});

    // data.save()

    // console.log(data);

    let data = await Todo.find().count()
    console.log(data)

    
})


module.exports = router;