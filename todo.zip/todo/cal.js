const express = require("express");
const bodyParser = require("body-parser");
const path = require('path');
const app = express();
app.use(bodyParser.urlencoded({extended:true}));
const port = 8000;

// const lightTheme = "styles/light.css";
// const darkTheme = "styles/dark.css";
// const sunIcon = "assets/SunIcon.svg";
// const moonIcon = "assets/MoonIcon.svg";
// const themeIcon = document.getElementById("theme-icon");
// const res = document.getElementById("result");
// const toast = document.getElementById("toast");
const Static =path.join(__dirname, "../public");
app.use(express.static(Static));

app.get("/", function (req, res) {
    res.sendFile(__dirname + "/" + "cal.html");
});


function calculate(value) {
  const calculatedValue = eval(value || null);
  if (isNaN(calculatedValue)) {
    res.value = "Can't divide 0 with 0";
    setTimeout(() => {
      res.value = "";
    }, 1300);
  } else {
    res.value = calculatedValue;
  }
}



// Displays entered value on screen.
function liveScreen(enteredValue) {
  if (!res.value) {
    res.value = "";
  }
  res.value += enteredValue;
}


document.addEventListener("keydown", keyboardInputHandler);


function keyboardInputHandler(e) {
  
  e.preventDefault();
  //grabbing the liveScreen

  //numbers
  if (e.key === "0") {
    res.value += "0";
  } else if (e.key === "1") {
    res.value += "1";
  } else if (e.key === "2") {
    res.value += "2";
  } else if (e.key === "3") {
    res.value += "3";
  } else if (e.key === "4") {
    res.value += "4";
  } else if (e.key === "5") {
    res.value += "5";
  } else if (e.key === "6") {
    res.value += "6";
  } else if (e.key === "7") {
    res.value += "7";
  } else if (e.key === "7") {
    res.value += "7";
  } else if (e.key === "8") {
    res.value += "8";
  } else if (e.key === "9") {
    res.value += "9";
  }

  //operators
  if (e.key === "+") {
    res.value += "+";
  } else if (e.key === "-") {
    res.value += "-";
  } else if (e.key === "*") {
    res.value += "*";
  } else if (e.key === "/") {
    res.value += "/";
  }

  //decimal key
  if (e.key === ".") {
    res.value += ".";
  }

  //press enter to see result
  if (e.key === "Enter") {
    calculate(result.value);
  }

  
  if (e.key === "Backspace") {
    const resultInput = res.value;
   
    res.value = resultInput.substring(0, res.value.length - 1);
  }
}
app.listen(port,()=>{
    console.log(`example app listening at http://localhost:${port}`)
  })